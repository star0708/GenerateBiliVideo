// 监听来自 content.js 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "download") {
        chrome.downloads.download({
            url: request.url,
            // 现在的 request.filename 包含了相对路径 (例如: 标题/标题.jpg)
            // Chrome 会自动在默认下载目录下创建这个文件夹
            filename: request.filename, 
            conflictAction: "uniquify", // 如果文件名重复，自动重命名
            saveAs: false // 设置为 false 则直接下载到默认位置，不弹出另存为窗口
        });
    }
});