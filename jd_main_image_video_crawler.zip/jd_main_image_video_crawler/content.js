(function() {
    console.log("京东素材抓取助手：已启动");

    function injectUI() {
        if (document.getElementById('jd-snatch-container')) return;
        if (!document.body) return;

        const container = document.createElement('div');
        container.id = 'jd-snatch-container';
        container.style.cssText = `
            position: fixed; top: 120px; right: 20px; z-index: 9999999;
            display: flex; flex-direction: column; align-items: flex-end; gap: 8px;
        `;

        const optLabel = document.createElement('label');
        optLabel.style.cssText = `
            background: rgba(255,255,255,0.9); padding: 5px 10px; border-radius: 4px;
            font-size: 12px; color: #333; box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            display: flex; align-items: center; cursor: pointer; border: 1px solid #ddd;
        `;
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = 'grab-params-check';
        checkbox.checked = true; 
        checkbox.style.marginRight = '5px';
        
        optLabel.appendChild(checkbox);
        optLabel.appendChild(document.createTextNode('抓取商品价格与参数'));

        const btn = document.createElement('button');
        btn.id = 'jd-snatch-btn';
        btn.innerText = '📂 抓取素材';
        btn.style.cssText = `
            padding: 12px 20px; background: #e1251b; color: #fff;
            border: 2px solid #fff; border-radius: 50px; cursor: pointer;
            font-weight: bold; box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;

        container.appendChild(optLabel);
        container.appendChild(btn);
        document.body.appendChild(container);

       btn.onclick = () => {
            try {
                // --- 1. 标题提取 ---
                let title = "";
                const titleSelectors = ['.sku-name', '.itemInfo-wrap h1', '.sku-title-name', 'h1', '.p-name'];
                for (let s of titleSelectors) {
                    const el = document.querySelector(s);
                    if (el && el.innerText.trim()) {
                        title = el.innerText.trim().replace(/\s+/g, ' ').replace(/\n|\r/g, '');
                        break;
                    }
                }
                if (!title) title = "jd_item_" + Date.now();

                let fileNameBase = title.replace(/[\\/:*?"<>|]/g, "_").replace(/[\x00-\x1F\x7F]/g, "").trim();
                fileNameBase = fileNameBase.replace(/[\s.]+$/, ''); 
                if (fileNameBase.length > 50) fileNameBase = fileNameBase.substring(0, 50).replace(/[\s.]+$/, '');

                // --- 2. 提取主图 ---
                const firstImg = document.querySelector('.image-carousel-track img.image, #spec-list img, #main-img, .spec-items img');
                if (firstImg) {
                    let rawUrl = firstImg.getAttribute('data-origin') || firstImg.getAttribute('data-url') || firstImg.src || firstImg.getAttribute('data-lazyload');
                    if (rawUrl) {
                        let imgUrl = rawUrl.startsWith('//') ? 'https:' + rawUrl : rawUrl;
                        imgUrl = imgUrl.replace(/\.(avif|webp)$/i, '').replace(/\/s\d+x\d+_(?=jfs)/, '/');
                        chrome.runtime.sendMessage({
                            action: "download",
                            url: imgUrl,
                            filename: `${fileNameBase}/${fileNameBase}_主图.jpg`
                        });
                    }
                }

                // --- 3. 提取视频 ---
                const videoEl = document.querySelector('video');
                if (videoEl && videoEl.src && !videoEl.src.startsWith('blob:')) {
                    let videoUrl = videoEl.src.startsWith('//') ? 'https:' + videoEl.src : videoEl.src;
                    chrome.runtime.sendMessage({
                        action: "download",
                        url: videoUrl,
                        filename: `${fileNameBase}/${fileNameBase}_视频.mp4`
                    });
                }

                // --- 4. 提取价格与参数 (兼容多重结构) ---
                if (checkbox.checked) {
                    let textContent = `商品全称：${title}\n`;

                    // 价格抓取优化：适配吸顶栏和普通栏
                    let price = "暂无价格";
                    const priceSelector = '.product-price--value, .p-price .price, #jd-price, .J-p-4652';
                    const priceVal = document.querySelector(priceSelector);
                    
                    if (priceVal) {
                        let raw = priceVal.innerText.trim().replace(/[^\d.]/g, '');
                        // 依然执行取整逻辑
                        price = raw ? Math.floor(parseFloat(raw)).toString() : "暂无价格";
                    }
                    textContent += `价格：￥${price}\n\n【规格参数】\n`;

                    // 参数抓取优化：适配新版 scoped 结构及顶部高亮灰色区域
                    let foundParams = false;
                    const items = document.querySelectorAll('.item');

                    items.forEach(item => {
                        // 1. 尝试匹配常规参数结构 (如：品牌、适用面积等)
                        const labelText = item.querySelector('.label .text');
                        const valueText = item.querySelector('.value .text');

                        // 2. 尝试匹配顶部灰色高亮参数结构 (如：6400M 无线速率)
                        const highlightLabel = item.querySelector('.desc .text');
                        const highlightValue = item.querySelector('.title');

                        if (labelText && valueText) {
                            const k = labelText.innerText.trim();
                            const v = valueText.innerText.trim();
                            if (k) {
                                textContent += `${k}：${v}\n`;
                                foundParams = true;
                            }
                        } else if (highlightLabel && highlightValue) {
                            const k = highlightLabel.innerText.trim();
                            const v = highlightValue.innerText.trim();
                            if (k) {
                                textContent += `${k}：${v}\n`;
                                foundParams = true;
                            }
                        }
                    });

                    // 兜底旧版结构
                    if (!foundParams) {
                        const legacy = document.querySelectorAll('.parameter2 li, .p-parameter li');
                        legacy.forEach(li => {
                            textContent += li.innerText.trim() + '\n';
                            foundParams = true;
                        });
                    }

                    // 下载参数 TXT
                    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        chrome.runtime.sendMessage({
                            action: "download",
                            url: e.target.result,
                            filename: `${fileNameBase}/${fileNameBase}_参数.txt`
                        });
                    };
                    reader.readAsDataURL(blob);
                }

                btn.innerText = '✅ 指令已发送';
                setTimeout(() => { btn.innerText = '📂 抓取素材'; }, 3000);

            } catch (err) {
                console.error("抓取异常:", err);
                btn.innerText = '❌ 识别失败';
                setTimeout(() => { btn.innerText = '📂 抓取素材'; }, 3000);
            }
        };
    }

    window.addEventListener('load', injectUI);
    setInterval(injectUI, 2000);
})();